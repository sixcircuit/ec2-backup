<?php
/** 
 *  PHP Version 5
 *
 *  @category    Amazon
 *  @package     Amazon_EC2
 *  @copyright   Copyright 2008-2009 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *  @link        http://aws.amazon.com
 *  @license     http://aws.amazon.com/apache2.0  Apache License, Version 2.0
 *  @version     2009-11-30
 */
/******************************************************************************* 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon EC2 PHP5 Library
 *  Generated: Fri Dec 11 13:55:19 PST 2009
 * 
 */

/**
 *  @see Amazon_EC2_Model
 */
require_once ('Amazon/EC2/Model.php');  

    

/**
 * Amazon_EC2_Model_InstanceMonitoring
 * 
 * Properties:
 * <ul>
 * 
 * <li>InstanceId: string</li>
 * <li>Monitoring: Amazon_EC2_Model_Monitoring</li>
 *
 * </ul>
 */ 
class Amazon_EC2_Model_InstanceMonitoring extends Amazon_EC2_Model
{


    /**
     * Construct new Amazon_EC2_Model_InstanceMonitoring
     * 
     * @param mixed $data DOMElement or Associative Array to construct from. 
     * 
     * Valid properties:
     * <ul>
     * 
     * <li>InstanceId: string</li>
     * <li>Monitoring: Amazon_EC2_Model_Monitoring</li>
     *
     * </ul>
     */
    public function __construct($data = null)
    {
        $this->_fields = array (
        'InstanceId' => array('FieldValue' => null, 'FieldType' => 'string'),
        'Monitoring' => array('FieldValue' => null, 'FieldType' => 'Amazon_EC2_Model_Monitoring'),
        );
        parent::__construct($data);
    }

        /**
     * Gets the value of the InstanceId property.
     * 
     * @return string InstanceId
     */
    public function getInstanceId() 
    {
        return $this->_fields['InstanceId']['FieldValue'];
    }

    /**
     * Sets the value of the InstanceId property.
     * 
     * @param string InstanceId
     * @return this instance
     */
    public function setInstanceId($value) 
    {
        $this->_fields['InstanceId']['FieldValue'] = $value;
        return $this;
    }

    /**
     * Sets the value of the InstanceId and returns this instance
     * 
     * @param string $value InstanceId
     * @return Amazon_EC2_Model_InstanceMonitoring instance
     */
    public function withInstanceId($value)
    {
        $this->setInstanceId($value);
        return $this;
    }


    /**
     * Checks if InstanceId is set
     * 
     * @return bool true if InstanceId  is set
     */
    public function isSetInstanceId()
    {
        return !is_null($this->_fields['InstanceId']['FieldValue']);
    }

    /**
     * Gets the value of the Monitoring.
     * 
     * @return Monitoring Monitoring
     */
    public function getMonitoring() 
    {
        return $this->_fields['Monitoring']['FieldValue'];
    }

    /**
     * Sets the value of the Monitoring.
     * 
     * @param Monitoring Monitoring
     * @return void
     */
    public function setMonitoring($value) 
    {
        $this->_fields['Monitoring']['FieldValue'] = $value;
        return;
    }

    /**
     * Sets the value of the Monitoring  and returns this instance
     * 
     * @param Monitoring $value Monitoring
     * @return Amazon_EC2_Model_InstanceMonitoring instance
     */
    public function withMonitoring($value)
    {
        $this->setMonitoring($value);
        return $this;
    }


    /**
     * Checks if Monitoring  is set
     * 
     * @return bool true if Monitoring property is set
     */
    public function isSetMonitoring()
    {
        return !is_null($this->_fields['Monitoring']['FieldValue']);

    }




}